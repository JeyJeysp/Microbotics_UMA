/*
 * main.h
 *
 *  Created on: 13 oct. 2020
 *      Author: Nacho
 */

#ifndef MAIN_H_
#define MAIN_H_

#include <stdint.h>
#include <stdbool.h>

extern void configServos();
extern void cambiaCiclo(uint32_t ui32DutyCycle1);

uint32_t ui32DutyCycle1, maxCount, minCount, cycle_changes;

#endif /* MAIN_H_ */
